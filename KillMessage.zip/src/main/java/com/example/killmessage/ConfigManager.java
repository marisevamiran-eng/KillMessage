package com.example.killmessage;

import org.bukkit.configuration.file.FileConfiguration;

public class ConfigManager {

    private final KillMessage plugin;

    public String displayMode;
    public int fadeIn, stay, fadeOut;
    public String titleText, subtitleText, actionbarText, chatText;
    public boolean soundEnabled;
    public String soundName;
    public float soundVolume, soundPitch;

    public ConfigManager(KillMessage plugin) {
        this.plugin = plugin;
        load();
    }

    public void load() {
        plugin.reloadConfig();
        FileConfiguration cfg = plugin.getConfig();

        displayMode = cfg.getString("display-mode", "ALL").toUpperCase();
        fadeIn = cfg.getInt("title.fade-in", 5);
        stay = cfg.getInt("title.stay", 30);
        fadeOut = cfg.getInt("title.fade-out", 10);

        titleText = cfg.getString("title-text", "&c&l+1 KILL");
        subtitleText = cfg.getString("subtitle-text", "&7Вы убили &e%victim%");
        actionbarText = cfg.getString("actionbar-text", "&a+1 &7| &e%victim%");
        chatText = cfg.getString("chat-text", "&8[&c☠&8] &7Вы убили &e%victim%");

        soundEnabled = cfg.getBoolean("sound.enabled", true);
        soundName = cfg.getString("sound.name", "ENTITY_PLAYER_LEVELUP");
        soundVolume = (float) cfg.getDouble("sound.volume", 1.0);
        soundPitch = (float) cfg.getDouble("sound.pitch", 1.5);
    }
}