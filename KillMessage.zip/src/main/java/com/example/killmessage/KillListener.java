package com.example.killmessage;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.title.Title;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

import java.time.Duration;

public class KillListener implements Listener {

    private final KillMessage plugin;
    private final ConfigManager cfg;
    private final LegacyComponentSerializer legacy = LegacyComponentSerializer.legacyAmpersand();

    public KillListener(KillMessage plugin) {
        this.plugin = plugin;
        this.cfg = plugin.getConfigManager();
    }

    @EventHandler
    public void onKill(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        Player killer = victim.getKiller();

        if (killer == null) return;
        if (killer.getUniqueId().equals(victim.getUniqueId())) return;

        String victimName = victim.getName();

        Component titleComp = legacy.deserialize(
                cfg.titleText.replace("%player%", victimName)
        );
        Component subtitleComp = legacy.deserialize(
                cfg.subtitleText.replace("%player%", victimName)
        );

        Title.Times times = Title.Times.times(
                Duration.ofMillis(cfg.fadeIn * 50L),
                Duration.ofMillis(cfg.stay * 50L),
                Duration.ofMillis(cfg.fadeOut * 50L)
        );

        switch (cfg.displayMode) {
            case "TITLE" ->
                    killer.showTitle(Title.title(titleComp, Component.empty(), times));
            case "SUBTITLE" ->
                    killer.showTitle(Title.title(Component.empty(), subtitleComp, times));
            case "BOTH" ->
                    killer.showTitle(Title.title(titleComp, subtitleComp, times));
            default ->
                    killer.showTitle(Title.title(titleComp, subtitleComp, times));
        }

        if (cfg.soundEnabled && cfg.soundName != null && !cfg.soundName.isEmpty()) {
            try {
                Sound sound = Sound.valueOf(cfg.soundName.toUpperCase());
                killer.playSound(killer.getLocation(), sound, cfg.soundVolume, cfg.soundPitch);
            } catch (IllegalArgumentException ignored) {
                plugin.getLogger().warning("Неверный звук: " + cfg.soundName);
            }
        }
    }
}