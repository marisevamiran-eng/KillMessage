package com.example.killmessage;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;

public class KillMessage extends JavaPlugin {

    private ConfigManager configManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        configManager = new ConfigManager(this);
        getServer().getPluginManager().registerEvents(new KillListener(this), this);

        getCommand("killmessage").setExecutor(this);

        TitleCommand titleCmd = new TitleCommand(this);
        getCommand("title").setExecutor(titleCmd);
        getCommand("title").setTabCompleter(titleCmd);

        getLogger().info("KillMessage включен!");
    }

    @Override
    public void onDisable() {
        getLogger().info("KillMessage выключен!");
    }

    public ConfigManager getConfigManager() {
        return configManager;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (command.getName().equalsIgnoreCase("killmessage")) {
            if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
                if (!sender.hasPermission("killmessage.reload")) {
                    sender.sendMessage("§cНет прав.");
                    return true;
                }
                configManager.load();
                sender.sendMessage("§aКонфиг перезагружен!");
                return true;
            }
            sender.sendMessage("§eИспользование: /killmessage reload");
            return true;
        }
        return false;
    }
}