package com.example.killmessage;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class TitleCommand implements CommandExecutor, TabCompleter {

    private final KillMessage plugin;
    private final LegacyComponentSerializer legacy = LegacyComponentSerializer.legacyAmpersand();

    public TitleCommand(KillMessage plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {

        if (!sender.hasPermission("killmessage.title")) {
            sender.sendMessage("§cНет прав.");
            return true;
        }

        if (args.length < 3) {
            sender.sendMessage("§eИспользование: /title <игрок> <title|subtitle|actionbar|chat|all> <текст>");
            return true;
        }

        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            sender.sendMessage("§cИгрок §e" + args[0] + " §cне найден.");
            return true;
        }

        String type = args[1].toLowerCase();
        String text = String.join(" ", Arrays.copyOfRange(args, 2, args.length));
        text = text.replace("%player%", target.getName());

        Component component = legacy.deserialize(text);

        ConfigManager cfg = plugin.getConfigManager();
        Title.Times times = Title.Times.times(
                Duration.ofMillis(cfg.fadeIn * 50L),
                Duration.ofMillis(cfg.stay * 50L),
                Duration.ofMillis(cfg.fadeOut * 50L)
        );

        switch (type) {
            case "title" -> {
                target.showTitle(Title.title(component, Component.empty(), times));
                sender.sendMessage("§aОтправлено §e" + target.getName() + "§a: title");
            }
            case "subtitle" -> {
                target.showTitle(Title.title(Component.empty(), component, times));
                sender.sendMessage("§aОтправлено §e" + target.getName() + "§a: subtitle");
            }
            case "actionbar" -> {
                target.sendActionBar(component);
                sender.sendMessage("§aОтправлено §e" + target.getName() + "§a: actionbar");
            }
            case "chat" -> {
                target.sendMessage(component);
                sender.sendMessage("§aОтправлено §e" + target.getName() + "§a: chat");
            }
            case "all" -> {
                target.showTitle(Title.title(component, component, times));
                target.sendActionBar(component);
                target.sendMessage(component);
                sender.sendMessage("§aОтправлено §e" + target.getName() + "§a: всё");
            }
            default -> {
                sender.sendMessage("§cНеизвестный тип: §e" + type);
                sender.sendMessage("§7Доступно: title, subtitle, actionbar, chat, all");
            }
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                      @NotNull String alias, @NotNull String[] args) {
        List<String> list = new ArrayList<>();
        if (args.length == 1) {
            for (Player p : Bukkit.getOnlinePlayers()) list.add(p.getName());
        } else if (args.length == 2) {
            list.addAll(Arrays.asList("title", "subtitle", "actionbar", "chat", "all"));
        }
        String last = args[args.length - 1].toLowerCase();
        list.removeIf(s -> !s.toLowerCase().startsWith(last));
        return list;
    }
}